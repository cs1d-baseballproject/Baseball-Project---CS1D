var searchData=
[
  ['database',['database',['../classdatabase.html',1,'']]],
  ['distance',['Distance',['../class_distance.html',1,'']]]
];
